# DemoPackage.demo1.py
def myfunc1():
    print("DemoPackage.demo1.myfunc1()")

def myfunc2():
    print("DemoPackage.demo1.myfunc2()")
    
