a = 0
if a and 10 / a:
    print("a가 0입니다")
else:
    print("에러 없이 통과")
    
